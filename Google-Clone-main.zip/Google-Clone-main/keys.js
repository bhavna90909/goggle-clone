// API KEY -- https://developers.google.com/custom-search/v1/using_rest

// CONTEXT KEY -- https://cse.google.com/cse/create/new




export const API_KEY = process.env.API_KEY;

export const API_SECRET = process.env.API_SECRET;

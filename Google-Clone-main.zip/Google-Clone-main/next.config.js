module.exports = {
  reactStrictMode: true,

  images: {
    domains: ['www.google.co.in']
  },
  env: {
    API_SECRET: 'eda89ce67f959a2cc',
    API_KEY: 'AIzaSyAHi-PlaQFWh-p4BbqFR1rzrqJkNXsAkXU'
  },
};

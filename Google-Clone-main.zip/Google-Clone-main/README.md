# Google-Clone
build clone of Google using NextJs, tailwind CSS, Google Custom Search API as a part of learning curve

# Technologies Used
* NextJS
* tailwind CSS
* Google Custom Search API

# Tools 
* VS Code
* Github

# Functionalities and Features 
* Custom Search
* pagination
* responsive



# Demo Photos
![image](https://user-images.githubusercontent.com/89068106/151971308-7a727370-5519-4355-9aa9-6c2a8667561e.png)

![eeeeCapture](https://user-images.githubusercontent.com/89068106/152092198-ea0a5882-86d4-41e2-b93d-d7c8fbc9f64c.PNG)


![Cdddhdapture](https://user-images.githubusercontent.com/89068106/152092192-da90d294-46a4-415f-aba8-bcf4cecf0877.PNG)



 



# Demo Video


https://user-images.githubusercontent.com/89068106/152091972-36c28c6d-8477-40fa-8f98-e75985a68a64.mp4


# Click Below link for live Demo
 <a href = "https://googleclone-five.vercel.app/">     Click Here  </a>


# connect with me





<!-- <h3 align="left">Connect with me:</h3> -->
<p align="left" margin="10px">
<a href="https://linkedin.com/in//keyur-diwan-889a59189" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="/keyur-diwan-889a59189" height="30" width="40" /></a>
<a href="https://twitter.com/keval_diwan" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="keval_diwan" height="30" width="40" /></a>


</p>


